package com.u6amtech.flutter_cynonyx_ecom

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
