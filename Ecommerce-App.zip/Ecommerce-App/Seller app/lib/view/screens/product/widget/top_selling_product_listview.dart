import 'package:flutter/material.dart';

class TopSellingProductListView extends StatelessWidget {
  const TopSellingProductListView({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
