import 'package:flutter/material.dart';

class CouponScreen extends StatefulWidget {
  const CouponScreen({Key key}) : super(key: key);

  @override
  State<CouponScreen> createState() => _CouponScreenState();
}

class _CouponScreenState extends State<CouponScreen> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
